/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_4;

import java.util.*;

/**
 *
 * @author Lenovo
 */
public class Ejercicio_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        int edad=0;
        int respuesta=0;
        int precio=8500;
        double descuento=0;
        double categoria1=0;
        double categoria2=0;
        double categoria3=0;
        double categoria4=0;
        double categoria5=0;
        double total=0;
        double suma=0;
        double totalneto=0;
        
        do {
            System.out.println("Ingresa la edad del cliente: ");
            edad =scan.nextInt();
            
            if (edad<5){
                System.out.println("Prohibido el ingreso");
            }else{
                if (edad<=14){
                    descuento = precio * 0.35;
                    categoria1 = categoria1 + descuento; 
                }else{
                    if (edad<=19){
                        descuento = precio * 0.25;
                        categoria2 = categoria2 + descuento; 
                    }else{
                        if (edad<= 45){
                            descuento = precio * 0.10;
                            categoria3 = categoria3 + descuento; 
                        }else{
                            if (edad<= 65){
                                descuento = precio * 0.25;
                                categoria4 = categoria4 + descuento; 
                            }else{
                                descuento = precio * 0.35;
                                categoria5 = categoria5 + descuento;
                            }
                        }
                    }
                }
            }
            System.out.println("Descuento= "+descuento);
            suma=suma+precio;
            total=total + descuento;
            System.out.println("");
            System.out.println("--------------------------------");
            System.out.println("--Deseas ingresar mas personas--");
            System.out.println("--1. Ingresar mas personas    --");
            System.out.println("--2. Salir del programa       --");
            System.out.println("--------------------------------");
            respuesta =scan.nextInt();
            
        } while (respuesta==1);
        
        
        System.out.println("");
        System.out.println("----------------------------------");
        System.out.println("---           TICKET           ---");
        System.out.println("---PRECIO DE LA ENTRADA=    "+precio+"  ---");
        System.out.println("------------DESCUENTO-------------");
        System.out.println("---Categoria 1 es= $"+ categoria1+"     ---");
        System.out.println("---Categoria 2 es= $"+ categoria2+"     ---");
        System.out.println("---Categoria 3 es= $"+ categoria3+"      ---");
        System.out.println("---Categoria 4 es= $"+ categoria4+"     ---");
        System.out.println("---Categoria 5 es= $"+ categoria5+"     ---");
        System.out.println("----------------------------------");
        System.out.println("---Total sin descuento= $"+suma+"---");
        System.out.println("---Descuento total    = $" +total+"---");
        totalneto=suma-total;
        System.out.println("---Total a pagar      = $"+totalneto+"---");
                
    }
    
}

