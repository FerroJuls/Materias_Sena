/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_1;

import java.util.*;

/**
 *
 * @author Lenovo
 */
public class Ejercicio_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        int diagonalMayor=0;
        int diagonalMenor=0;
        double area=0;
        
        System.out.println("Ingresa la longitud de la diagonal mayor: ");
        diagonalMayor =scan.nextInt(); 

        System.out.println("Ingresa la longitud de la diagonal menor: ");
        diagonalMenor =scan.nextInt(); 

        area = (diagonalMayor * diagonalMenor) / 2;

        System.out.println("El area del rombo es: " + area);
    }
    
}
