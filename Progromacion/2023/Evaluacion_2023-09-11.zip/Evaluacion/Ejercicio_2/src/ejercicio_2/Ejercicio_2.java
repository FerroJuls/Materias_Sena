/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_2;

import java.util.*;

/**
 *
 * @author Lenovo
 */
public class Ejercicio_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        //VARIABLES INFO ESTUDIANTE
        int promedio=0;
        int materiasReprobadas=0;
        int tipoEstudiante=0;
        int cant=0;
        int pagoProfesional=300;
        int pagoPreparatoria=180;
        int pago=0;
        double totalNeto=0;
        double total=0;
        double descuentot=0;
        
        
        
        //VARIABLE DESCUENTO Y UNIDADES
        double unidades=0;
        double descuento=0;
        
        //RECOLECTAR INFO
        System.out.println("------------------INGRESA-----------------");
        System.out.println("--Promedio del estudiante rango 10 a 100--");
        promedio =scan.nextInt();
        
        System.out.println("-----Cantidad de materias reprobadas:-----");
        materiasReprobadas =scan.nextInt();
        
        
        System.out.println("----------El estudiante es tipo:----------");
        System.out.println("1 = Preparatoria");
        System.out.println("2 = Profesional");
        tipoEstudiante =scan.nextInt();
        
        //CONDICIONES
        System.out.println("");
        System.out.println("");
        if (tipoEstudiante == 1){
            System.out.println("------Estudiante preparatoria------");
            pago=pagoPreparatoria;
            if (promedio >=95){
                unidades = 55;
                descuento = 0.25;
            }else{
                if (promedio>=90 & promedio < 95){
                    unidades = 50;
                    descuento = 0.1;
                }else{
                    if (promedio>=70 & promedio < 90){
                        unidades = 50;
                        descuento = 0;
                    }else{
                        if (materiasReprobadas<=3){
                            System.out.println(""+materiasReprobadas);
                            unidades = 45;
                        }else{
                            System.out.println(""+materiasReprobadas);
                            unidades = 40;
                        }
                    }
                }
            }
        }else{
            pago=pagoProfesional;
            System.out.println("------Estudiante profesional-------");
            if (promedio>=95){
                unidades = 55;
                descuento = 0.2;
            }else{
                unidades = 55;
                descuento = 0;
            }
        }
        
        
        System.out.println("-- Unidades                 "+unidades+" --");
        System.out.println("-- Descuento                "+descuento+" --");
        System.out.println("-----------------------------------");
        System.out.println("-- Materias reprobadas         "+materiasReprobadas+" --");
        System.out.println("-----------------------------------");
        
        total=((unidades/5)*pago);
        descuentot=total*descuento;
        totalNeto=total-descuentot;
        
        System.out.println("-- Total                  "+total+" --");
        System.out.println("-- Descuento               "+descuentot+" --");
        System.out.println("-----------------------------------");
        System.out.println("-- Total a pagar          "+totalNeto+" --");
    }
    
}