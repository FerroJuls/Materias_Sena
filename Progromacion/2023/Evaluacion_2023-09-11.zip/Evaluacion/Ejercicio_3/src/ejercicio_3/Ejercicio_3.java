/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3;

import java.util.*;

/**
 *
 * @author Lenovo
 */
public class Ejercicio_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        
        double promedio=0;
        int contador=0;
        int suma=0;
        int dia=0;
        int minuto=0;
        
        System.out.println("-----------MINUTOS POR DIA-----------");
        for (dia=1;dia<=10;dia++){
            System.out.println("--- Dia "+ dia+":                        ---");
            minuto =scan.nextInt();
            
            if (minuto>16){
                contador = contador + 1;
            }
            suma=suma+minuto;
        }
        promedio =suma/10;
        
        
        System.out.println("--------------------------------------");
        System.out.println("--- El promedio es         "+promedio+"mn  ---");
        System.out.println("--------------------------------------");
        System.out.println("--- Tiempo mayor a 16           "+contador+"  ---");
        System.out.println("--------------------------------------");
        
        
        if (contador ==0  | contador==1 | promedio <=15){
            System.out.println("----------------ES APTO---------------");
        }else{
            System.out.println("---------------NO ES APTO-------------");
        }
        
    }
    
}

