/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_7;

import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Ejercicio_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        double valorHoraExtra=0;
        double valorHora = 10000; 
        int horasNormales = 40;
        int empleado=0;
        int horasTrabajadas=0;
        double salarioSemana = 0;
        int horasExtras =0;
        valorHoraExtra = valorHora * 1.3; 

        for ( empleado = 1; empleado <= 5; empleado++) {
            System.out.println("----------------------------");
            System.out.println("---        FACTURA       ---");
            System.out.println(  "---       EMPLEADO #"+empleado+"    ---");
            System.out.print(  "---    HORAS LABORADAS   -");
            horasTrabajadas =scan.nextInt();

            

            if (horasTrabajadas <= horasNormales) {
                salarioSemana = horasTrabajadas * valorHora;
            } else {
                horasExtras = horasTrabajadas - horasNormales;
                salarioSemana = (horasNormales * valorHora) + (horasExtras * valorHoraExtra);
            }

            System.out.println(  "---Recibe        "+salarioSemana+"---");
            System.out.println("");
        }
    }
    
}
