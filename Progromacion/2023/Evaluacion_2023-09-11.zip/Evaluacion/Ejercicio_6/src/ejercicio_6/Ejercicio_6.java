/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_6;

import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Ejercicio_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here        
        Scanner scan = new Scanner(System.in);

        int num=0;
        int a=0;
        int b=0;
        int c=0;
        int d=0;
        int e=0;
        int f=0;
        int numInvertido=0;
        
        
        System.out.print("Ingrese un numero de 4 cifras: ");
        num =scan.nextInt();

        
        a = num / 1000;
        b = num - (a * 1000);
        c = b / 100;
        d = b - (c * 100);
        e = d / 10;
        f = d - (e * 10);
        numInvertido = (f * 1000)+(e * 100)+(c * 10)+a;


        System.out.println("Numero invertido: " + numInvertido);
    }
}
