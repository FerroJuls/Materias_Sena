/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_5;

import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Ejercicio_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        
        int estudiantes = 0;
        int calificacion=0;
        int cantidad=15;
        int punto1 = 0;
        int punto2 = 0;
        int punto3 = 0;
        int punto4 = 0;

        for ( estudiantes = 1; estudiantes <= cantidad; estudiantes++) {
            System.out.print("Ingrese la calificacion del estudiante " + estudiantes + ": ");
            calificacion =scan.nextInt();
           
            if (calificacion<50){
                punto1++;
            }else{
                if (calificacion >= 50 & calificacion <69){
                    punto2++;
                }else{
                    if (calificacion >= 70 & calificacion <80){
                        punto3++;
                    }else{
                        punto4++;
                    }
                }
            }
        }

        System.out.println("");
        System.out.println("----------------------------------");
        System.out.println("--Calificacion menor a 50:     " + punto1+"--");
        System.out.println("--Calificacion entre 50 y 69:  " + punto2+"--");
        System.out.println("--Calificacion entre 70 y 79:  " + punto3+"--");
        System.out.println("--Calificacion mayor a 80:     " + punto4+"--");
        System.out.println("----------------------------------");
    }
}

    
    
