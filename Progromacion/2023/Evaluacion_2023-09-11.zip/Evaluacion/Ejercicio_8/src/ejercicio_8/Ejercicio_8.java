/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_8;

import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Ejercicio_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        int n = 10;
        int i=0;
        int[] vectorA = new int[n];
        int[] vectorB = new int[n];
        int[] vectorC = new int[n];
        
         System.out.println("VECTOR A:");
        for (i = 0; i < n; i++) {
            System.out.print("Ingrese el valor " + (i + 1) + ": ");
            vectorA[i] = scan.nextInt();
        }
        
        System.out.println("");
        System.out.println("VECTOR B:");
        for (i = 0; i < n; i++) {
            System.out.print("Ingrese el valor " + (i + 1) + ": ");
            vectorB[i] = scan.nextInt();
        }

        for (i = 0; i < n; i++) {
            vectorC[i] = vectorA[i] + vectorB[i];
        }

        System.out.println("");
        System.out.println("VECTOR C total:");
        for (i = 0; i < n; i++) {
            System.out.print(vectorC[i] + " ");
        }
    }
    
}
