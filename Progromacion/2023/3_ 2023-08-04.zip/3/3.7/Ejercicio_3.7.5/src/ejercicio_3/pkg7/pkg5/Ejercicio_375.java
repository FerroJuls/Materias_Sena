/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg7.pkg5;

import java.util.Scanner;
/**
 *
 * @author SENA
 */
public class Ejercicio_375 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scan = new Scanner(System.in);
        double num1=0;
        double num2=0;
        double num3=0;
        double area=0;
        
        
        
        String palabra;
        System.out.println("Ingrese la figura que le desea calcular el area");
        palabra = scan.next();

            switch (palabra) {
                case "trapecio" , "Trapesio"->{
                        System.out.println("Digita la altura del Trapecio");
                        num1=scan.nextInt();
                        System.out.println("Digita la base (BAJA) del Trapecio");
                        num2=scan.nextInt();
                        System.out.println("Digita la base (ALTA) del Trapecio");
                        num3=scan.nextInt();
                        area = ((num1+num2)*num1)/2;
                        System.out.println("La area es: " + area);
                }
                case "triangulo" , "Triangulo", "triángulo","Triángulo"->{
                        System.out.println("Digita la altura del Triangulo");
                        num1=scan.nextInt();
                        System.out.println("Digita la base del Triangulo");
                        num2=scan.nextInt();
                        area = (num2*num1)/2;
                        System.out.println("La area es: " + area);
                }
                case "cuadrado" , "Cuadrado"->{
                        System.out.println("Digita el lado del Cuadrado");
                        num1=scan.nextInt();
                        area = num1*num1;
                        System.out.println("La area es: " + area);
                }
                case "Rectángulo" , "rectángulo", "Rectangulo", "rectangulo"->{
                        System.out.println("Digita la altura del Rectangulo");
                        num1=scan.nextInt();
                        System.out.println("Digita la base del Rectangulo");
                        num2=scan.nextInt();
                        area = num1*num2;
                        System.out.println("La area es: " + area);
                }
                case " circunferencia" , " Circunferencia"->{
                        System.out.println("Digita el radio de la esfera");
                        num1=scan.nextInt();
                        area = Math.PI*Math.pow(num1, 2);
                        System.out.println("La area es: " + area);
                }
                default -> {
                    System.out.println("Opcion no valida");
                }
            }
    }
    
}
