/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg7.pkg2;

import java.util.Scanner;
/**
 *
 * @author SENA
 */
public class Ejercicio_372 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scan =new Scanner(System.in);
        int num;
        System.out.println("Ingrese un numero:");
        num=scan.nextInt();

            switch (num) {
                case 0,1,2,3,4,5,6,7,8,9 -> System.out.println("Si es un digito");
                default -> {
                    System.out.println("No es un digito");
                }
            }
    }
    
}
