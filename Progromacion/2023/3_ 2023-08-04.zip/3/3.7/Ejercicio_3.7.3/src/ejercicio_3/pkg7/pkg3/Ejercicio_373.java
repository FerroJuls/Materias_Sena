/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg7.pkg3;

import java.util.Scanner;

/**
 *
 * @author SENA
 */
public class Ejercicio_373 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner scan = new Scanner(System.in);
        char letra;
        System.out.println("Ingrese letra y tedire cual es una vocal:");
        letra = scan.next().charAt(0);

            switch (letra) {
                case 'a','A', 'e','E', 'i','I', 'o','O', 'u','U' -> System.out.println("Es una vocal");
                default -> {
                    System.out.println("Opcion no valida");
                }
            }
        }
    }
        
