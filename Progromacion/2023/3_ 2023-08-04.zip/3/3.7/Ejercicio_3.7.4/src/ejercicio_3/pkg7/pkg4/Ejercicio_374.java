/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg7.pkg4;

import java.util.Scanner;

/**
 *
 * @author SENA
 */
public class Ejercicio_374 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scan = new Scanner(System.in);
        char letra;
        System.out.println("Ingrese un numero romano para ver su equivalente en letra");
        letra= scan.next().charAt(0);
        switch (letra) {
            case 'I' -> {
                System.out.println("Su equivalente es: 1");
            }
            
            case 'V' -> {
                System.out.println("Su equivalente es: 5");
            }
            
            case 'X' -> {
                System.out.println("Su equivalente es: 10");
            }
            
            case 'L' ->  {
                System.out.println("Su equivalente es: 50");
            }
            
            case 'C' -> {
                System.out.println("Su equivalente es: 100");
            }
            
            case 'D' -> {
                System.out.println("Su equivalente es: 500");
            }
            
            case 'M' -> {
                System.out.println("Su equivalente es: 1000");
            }
            
            
            default -> {
                System.out.println("Opcion no valida");   
            }
                
        }
    }
    
}
