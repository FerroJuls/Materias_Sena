/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg7.pkg1;

import java.util.Scanner;

/**
 *
 * @author SENA
 */
public class Ejercicio_371 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scan =new Scanner(System.in);
        int num;
        System.out.println("Ingrese un numero para ver su equivalente en letra");
        num=scan.nextInt();
        switch (num) {
            case 0 -> {
                System.out.println("Su equivalente en letra es: T");
            }
            case 1 -> {
                System.out.println("Su equivalente en letra es: R");
            }
            case 2 -> {
                System.out.println("Su equivalente en letra es: W");
            }
            case 3 -> {
                System.out.println("Su equivalente en letra es: A");
            }
            case 4 -> {
                System.out.println("Su equivalente en letra es: G");
            }
            case 5 -> {
                System.out.println("Su equivalente en letra es: M");
            }
            case 6 -> {
                System.out.println("Su equivalente en letra es: Y");
            }
            case 7 -> {
                System.out.println("Su equivalente en letra es: F");
            }
            case 8 -> {
                System.out.println("Su equivalente en letra es: P");
            }
            case 9 -> {
                System.out.println("Su equivalente en letra es: D");
            }
            case 10 -> {
                System.out.println("Su equivalente en letra es: X");
            }
            case 11 -> {
                System.out.println("Su equivalente en letra es: B");
            }
            case 12 -> {
                System.out.println("Su equivalente en letra es: N");
            }
            case 13 -> {
                System.out.println("Su equivalente en letra es: J");
            }
            case 14 -> {
                System.out.println("Su equivalente en letra es: Z");
            }
            case 15 -> {
                System.out.println("Su equivalente en letra es: S");
            }
            case 16 -> {
                System.out.println("Su equivalente en letra es: Q");
            }
            case 17 -> {
                System.out.println("Su equivalente en letra es: V");
            }
            case 18 -> {
                System.out.println("Su equivalente en letra es: H");
            }
            case 19 -> {
                System.out.println("Su equivalente en letra es: L");
            }
            case 20 -> {
                System.out.println("Su equivalente en letra es: C");
            }
            case 21 -> {
                System.out.println("Su equivalente en letra es: K");
            }
            case 22 -> {
                System.out.println("Su equivalente en letra es: E");
            }
            default -> {
                System.out.println("Opcion no valida");   
            }
                
        }
    }
    
}
