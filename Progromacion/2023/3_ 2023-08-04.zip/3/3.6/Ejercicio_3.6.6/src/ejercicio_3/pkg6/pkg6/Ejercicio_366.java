/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg6.pkg6;

import java.util.Scanner;
/**
 *
 * @author SENA
 */
public class Ejercicio_366 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int saldo;
        double prestamo=0;
        double saldoNuevo=0;
        double saldoNew=0;
        double dividir=0;
        
        Scanner scan=new Scanner(System.in);
        
        System.out.println("Digite su saldo:");
        saldo=scan.nextInt();
        
        if (saldo==0){
            prestamo = 10000-saldo;
            saldoNuevo = prestamo+saldo;
        }else{
            if (saldo<20000){
            prestamo = 20000-saldo;
            saldoNuevo = prestamo+saldo;
            }else{
                saldoNuevo = saldo;
            }
        }
        saldoNew = saldoNuevo - 7000;
        dividir = saldoNew/2;
        
        System.out.println("El dinero se repartira de la siguiente forma:");
        System.out.println("Computo:         $5000 ");
        System.out.println("Mobiliario:      $2000");
        System.out.println(  "Insumo:          $"+ dividir);
        System.out.println(  "Incentivos:      $"+ dividir);
        System.out.println(  "El prestamo fue: $"+ prestamo);
    }
    
}
