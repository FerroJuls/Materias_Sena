/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg6.pkg1;

import java.util.Scanner;
/**
 *
 * @author SENA
 */
public class Ejercicio_361 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        int cantidad;
        System.out.println("Ingrese la cantidad de compus que desea llevar");
        cantidad=scan.nextInt();
        double valor=0;
        double descuento=0;
        double valorT=0;
        
    if (cantidad<0){
            System.out.println("Error");
        }else{
                    if (cantidad<10 & cantidad>0){
            if (cantidad>=5){
            valor=cantidad*11000; 
            descuento=valor*0.2;
            valorT=valor-descuento;
          
        }else{
            valor=cantidad*11000; 
            descuento=valor*0.1;
            valorT=valor-descuento;

        }
        }else{
            valor=cantidad*11000; 
            descuento=valor*0.4;
            valorT=valor-descuento;
      
        }
          System.out.println("Su valor es:" + valor);
            System.out.println("Su descuento es:" + descuento);
            System.out.println("Su valor total es:" + valorT);
        }
    }
    
}
