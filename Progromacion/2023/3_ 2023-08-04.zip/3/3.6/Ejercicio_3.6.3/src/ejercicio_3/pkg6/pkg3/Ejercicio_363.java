/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg6.pkg3;

import java.util.Scanner;
/**
 *
 * @author SENA
 */
public class Ejercicio_363 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int r1;
        int r2;
        int r3;
        Scanner scan=new Scanner(System.in);
        System.out.println("Juego, solo podras responder si o no");
        System.out.println("Si = 1");
        System.out.println("No = 2");
        System.out.println("");
        System.out.println("1. Colon descubrio America?");
        r1=scan.nextInt();
        if (r1==1){
            System.out.println("2. La independencia de Mexico fue en el año 1810?");
            r2=scan.nextInt();
                if (r2==2){
                    System.out.println("3. The Doors fue un grupo de rock Americano?");
                    r3=scan.nextInt();
                        if (r3==1){
                            System.out.println("Obtuviste todas las respuesta correcta felicidades");
                        }else{
                            System.out.println("Obtuviste 2 respuestas correctas");
                        }
                }else{
                    System.out.println("Obtuviste 1 respuesta correcta");
                }
        }else{
            System.out.println("Obtuviste 0 respuestas correctas");
        }

    }
    
}
