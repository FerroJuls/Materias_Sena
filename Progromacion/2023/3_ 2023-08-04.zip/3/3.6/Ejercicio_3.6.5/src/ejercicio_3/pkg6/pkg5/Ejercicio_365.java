/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg6.pkg5;

import java.util.Scanner;
/**
 *
 * @author SENA
 */
public class Ejercicio_365 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scan=new Scanner(System.in);
        int kilo;
        int precio;
        double descuento=0;
        double total=0;
        
        
        System.out.println("Digita el numero de kilos:");
        kilo=scan.nextInt();
        System.out.println("Digita el precio:");
        precio=scan.nextInt();
        
        if (kilo>0 && kilo<=5){
                    if (kilo>2){
                        descuento = (precio*kilo)*0.1;
                        total = (precio*kilo)-descuento;
                    }else{
                        total = precio*kilo;
                    }
        }else{
                    if (kilo>5 && kilo<=10){
                        descuento = (precio*kilo)*0.15;
                        total = (precio*kilo)-descuento;
                    }else{
                        descuento = (precio*kilo)*0.2;
                        total = (precio*kilo)-descuento;
                    }  
        }
        System.out.println("El descuento es de: "+ descuento);
        System.out.println("El total a pagar es: "+ total);
    }
    
}
