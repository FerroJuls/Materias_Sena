/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg6.pkg2;

import java.util.Scanner;
/**
 *
 * @author SENA
 */
public class Ejercicio_362 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        int cantidad;
        System.out.println("Ingrese la cantidad de llantas que desea llevar");
        cantidad=scan.nextInt();
        double valor=0;
        double llanta1=300;
        double llanta2=250;
        double llanta3=200;
        
    if (cantidad<0){
            System.out.println("Error");
        }else{
        if (cantidad<10 & cantidad>0){
            if (cantidad<=5){
            valor=cantidad*llanta1; 
          System.out.println("El valor por llanta es " + llanta1);
          
        }else{
            valor=cantidad*llanta2; 
          System.out.println("El valor por llanta es " + llanta2);

        }
        }else{
            valor=cantidad*llanta3; 
          System.out.println("El valor por llanta es " + llanta3);
      
        }
          System.out.println("Su valor es:" + valor);
        }
    }
    
}
