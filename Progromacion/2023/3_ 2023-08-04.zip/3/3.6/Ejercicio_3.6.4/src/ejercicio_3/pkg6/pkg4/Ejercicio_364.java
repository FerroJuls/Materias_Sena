/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg6.pkg4;

import java.util.Scanner;
/**
 *
 * @author SENA
 */
public class Ejercicio_364 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int marca;
        int precio;
        double des5=0;
        double des10=0;
        double total=0;
        double iva=0;
        double totalneto=0;
                
        Scanner scan=new Scanner(System.in);
        System.out.println("Digita el valor del producto");
        precio=scan.nextInt();
        System.out.println("Digita la marca de aparato");
        System.out.println("Nosy = 1");
        System.out.println("otra marca = 2");
        marca=scan.nextInt();
        
        
        if (marca==1){
            des5 = precio*0.05;
        }else{
        }
        
        if (precio>=2000){
            des10 = precio*0.1;
        }else{
        }
        
        total = precio-des10-des5;
        iva = total*0.19;
        totalneto=total+iva;
        System.out.println("El subtotal es: "+ total);
        System.out.println("El iva es: "+ iva);
        System.out.println("El total neto es: "+ totalneto);
    }
    
}
