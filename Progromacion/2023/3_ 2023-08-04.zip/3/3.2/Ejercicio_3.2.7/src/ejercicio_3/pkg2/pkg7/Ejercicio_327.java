/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg2.pkg7;


import java.util.*;

/**
 *
 * @author SENA
 */
public class Ejercicio_327 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        
        
        System.out.println("Ingrese el primer numero");
        int num1=scan.nextInt(); 
        System.out.println("Ingrese el segundo numero");
        int num2=scan.nextInt(); 
        
        
        double doble=num1+num1; 
        double cuadrado=num2*num2; 
        double sumatoria=doble+cuadrado; 
        
        System.out.println("El doble del primer numero es:" + doble);
        System.out.println("El cuadrado del segundo numero es:" + cuadrado);
        System.out.println("La sumatoria de ambos numeros es:" + sumatoria);
    }
    }
    

