/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg2.pkg8;

import java.util.*;


/**
 *
 * @author SENA
 */
public class Ejercicio_328 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        
        
        System.out.println("Ingrese el primer numero");
        int num1=scan.nextInt(); 
        System.out.println("Ingrese el segundo numero");
        int num2=scan.nextInt(); 
        
        
        double suma=num1+num2; 
        
        System.out.println("La suma es:" + suma);
    }
    
}
