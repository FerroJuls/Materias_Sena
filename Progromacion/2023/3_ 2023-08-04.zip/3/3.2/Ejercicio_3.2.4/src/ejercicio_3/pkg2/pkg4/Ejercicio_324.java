/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg2.pkg4;


import java.util.*;

/**
 *
 * @author SENA
 */
public class Ejercicio_324 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        
        
        System.out.println("Ingrese numero");
        int real=scan.nextInt(); 
        
        System.out.println("El cuadrado es:");
        System.out.println(real*real*real);
    }
    
}
