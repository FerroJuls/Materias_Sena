/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg2.pkg5;


import java.util.*;

/**
 *
 * @author SENA
 */
public class Ejercicio_325 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scan=new Scanner(System.in);
        
        
        System.out.println("Ingrese numero");
        double real=scan.nextDouble(); 
        double suma=real+real;
        double cuadrado=real*real;
        double sumatoria=suma+cuadrado;
        System.out.println("La suma es "+suma);
        System.out.println("El cuadrado es "+cuadrado);
        System.out.println("La sumatoria es "+sumatoria);
        
        
    }
    
}
