/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_3.pkg2.pkg1;


import java.util.*;

/**
 *
 * @author SENA
 */
public class Ejercicio_321 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scan=new Scanner(System.in);
        
        System.out.println("Ingrese una palabra");
        String palabra=scan.nextLine(); 
        
        System.out.println("Su palabra es:");
        System.out.println(palabra ); 
    }
    
}
