/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package concesionario;

/**
 *
 * @author Lenovo
 */
    public class VentaMoto extends Vehiculo {
    private String nombreCliente;
    private int numeroVenta;
    private int montoPagado;

    // Constructor
    public VentaMoto(String marca, String modelo, int precio, String nombreCliente, int numeroVenta, int montoPagado) {
        super(marca, modelo, precio);
        this.nombreCliente = nombreCliente;
        this.numeroVenta = numeroVenta;
        this.montoPagado = montoPagado;
    }

    // Getters y setters
    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public int getNumeroVenta() {
        return numeroVenta;
    }

    public void setNumeroVenta(int numeroVenta) {
        this.numeroVenta = numeroVenta;
    }

    public int getMontoPagado() {
        return montoPagado;
    }

    public void setMontoPagado(int montoPagado) {
        this.montoPagado = montoPagado;
    }

    // Método para calcular el cambio
    public int calcularCambio() {
        int precioConIVA = calcularPrecioConIVA();
        return montoPagado - precioConIVA;
    }

    void imprimirFactura() {
        System.out.println("-------------------------");
        System.out.println("--      FACTURA       --");
        System.out.println("-- Nombre:       " + nombreCliente);
        System.out.println("-- Codigo:       " + numeroVenta);
        System.out.println("-------------------------");
        super.imprimirInformacion(); // Imprimir información del vehículo
        System.out.println("-------------------------");
        System.out.println("-- Monto Pagado: $" + montoPagado);
        System.out.println("-------------------------");
        System.out.println("-- IVA:          $" + calcularPrecioConIVA());
        System.out.println("-------------------------");
        System.out.println("-- Total Neto:   $" + super.calcularPrecioConIVA());
        System.out.println("-------------------------");
        System.out.println("-- Cambio  :     $" + calcularCambio());
        System.out.println("-------------------------");
        System.out.println("- GRACIAS POR TU COMPRA -");
        System.out.println("-------------------------");
    }


}
