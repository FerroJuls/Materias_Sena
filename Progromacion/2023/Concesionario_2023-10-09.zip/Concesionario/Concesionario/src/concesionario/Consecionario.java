/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package concesionario;


import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Consecionario {
    
    public static void main(String[] args) {
        VentaMoto ventaMoto = new VentaMoto("Honda", "CBR", 5000, "Maidy", 678, 6000);
        VentaMoto ventaMoto2 = new VentaMoto("Yamaha", "xtr", 4000, "Anyi", 132, 5500);
        VentaCarro ventaCarro = new VentaCarro("Toyota", "Captiva", 12000, "Dylan", 276, 22000);
        VentaCarro ventaCarro2 = new VentaCarro("Toyota", "RX", 10000, "Julian", 297, 22000);
        
        // Puedes llamar a métodos en los objetos creados
        ventaMoto.imprimirFactura();
        System.out.println("");
        System.out.println("");
        ventaMoto2.imprimirFactura();
        System.out.println("");
        System.out.println("");
        ventaCarro.imprimirFactura();
        System.out.println("");
        System.out.println("");
        ventaCarro2.imprimirFactura();
        //ventaCarro.imprimirFactura();
        
        // Aquí puedes continuar con la lógica de tu programa
        
        // Por ejemplo, puedes interactuar con el usuario y realizar otras operaciones.
        
    }
        
    }
    


